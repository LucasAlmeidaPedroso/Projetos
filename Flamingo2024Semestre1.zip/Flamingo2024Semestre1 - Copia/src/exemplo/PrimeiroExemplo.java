package exemplo;

public class PrimeiroExemplo {
public static void main(String[] args) {
	System.out.println("Teste");
}
}
