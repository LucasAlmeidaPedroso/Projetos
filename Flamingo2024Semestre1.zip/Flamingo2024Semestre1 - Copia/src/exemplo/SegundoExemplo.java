package exemplo;

public class SegundoExemplo {
	public static void main(String[] args) {
		System.out.println("Lucas");
		System.out.println("Endereço = Rua blzblz");
		System.out.println("Profissão programador");
	}
	
}
