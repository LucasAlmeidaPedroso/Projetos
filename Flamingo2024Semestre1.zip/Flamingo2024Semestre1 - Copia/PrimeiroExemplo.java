package exemplo;

public class PrimeiroExemplo {

}
